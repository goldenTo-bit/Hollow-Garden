-keepclassmembers class com.hollowgarden.app.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
