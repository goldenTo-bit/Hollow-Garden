package com.hollowgarden.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONObject
import kotlin.concurrent.thread

/** Home-screen widget: real weather where you are, plus how your garden is doing. */
class GardenWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        thread {
            try {
                WeatherFetcher.refresh(context)
                render(context, manager, ids)
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        private val NAMES = mapOf(
            "sunny" to ("☀️" to "Sunny"), "cloudy" to ("☁️" to "Cloudy"), "rain" to ("🌧️" to "Rain"),
            "storm" to ("⛈️" to "Storm"), "snow" to ("❄️" to "Snow"), "fog" to ("🌫️" to "Fog"),
            "windy" to ("🍃" to "Windy")
        )

        fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, GardenWidget::class.java))
            if (ids.isNotEmpty()) render(context, mgr, ids)
        }

        private fun render(context: Context, mgr: AppWidgetManager, ids: IntArray) {
            val views = RemoteViews(context.packageName, R.layout.widget_garden)

            val w: JSONObject? = WeatherFetcher.cached(context)?.let {
                try { JSONObject(it) } catch (e: Exception) { null }
            }
            if (w != null) {
                val (emoji, name) = NAMES[w.optString("c")] ?: ("🌱" to "Garden")
                views.setTextViewText(R.id.tvWeather, "$emoji $name  ${w.optInt("t")}°C")
                views.setTextViewText(R.id.tvPlace, w.optString("place", "your area"))
            } else {
                views.setTextViewText(R.id.tvWeather, "🌱 Hollow Garden")
                views.setTextViewText(R.id.tvPlace, "Open the game to allow location")
            }

            val s = WeatherFetcher.summary(context)
            views.setTextViewText(
                R.id.tvStatus,
                if (s != null) "🌾 ${s.optInt("ready")} ready · 💧 ${s.optInt("dry")} thirsty · 🪙 ${s.optInt("coins")}"
                else "Plant something to see your garden here"
            )

            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, open)
            for (id in ids) mgr.updateAppWidget(id, views)
        }
    }
}
