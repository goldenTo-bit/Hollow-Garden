package com.hollowgarden.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Finds the phone's approximate location, asks Open-Meteo (free, no API key) for the
 * current weather and stores the result as a small JSON string:
 * {"c":"sunny","t":23,"place":"Cairo","ts":1730000000000}
 * "c" is one of the garden's own weather names: sunny, cloudy, rain, storm, snow, fog, windy.
 */
object WeatherFetcher {
    private const val PREFS = "garden"

    fun cached(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("weather", null)

    fun summary(ctx: Context): JSONObject? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("summary", null)?.let {
            try { JSONObject(it) } catch (e: Exception) { null }
        }

    fun saveSummary(ctx: Context, json: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("summary", json).apply()
    }

    /** Blocking. Call from a background thread. Returns true when fresh weather was stored. */
    fun refresh(ctx: Context): Boolean {
        val loc = location(ctx) ?: return false
        return try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}" +
                    "&current=temperature_2m,weather_code,wind_speed_10m&timezone=auto"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val cur = JSONObject(body).getJSONObject("current")
            val code = cur.getInt("weather_code")
            val wind = cur.optDouble("wind_speed_10m", 0.0)
            val out = JSONObject()
                .put("c", condition(code, wind))
                .put("t", Math.round(cur.getDouble("temperature_2m")).toInt())
                .put("place", placeName(ctx, loc))
                .put("ts", System.currentTimeMillis())
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("weather", out.toString()).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun condition(code: Int, wind: Double): String = when (code) {
        0, 1 -> if (wind >= 35) "windy" else "sunny"
        2, 3 -> if (wind >= 35) "windy" else "cloudy"
        45, 48 -> "fog"
        in 51..67, in 80..82 -> "rain"
        in 71..77, 85, 86 -> "snow"
        in 95..99 -> "storm"
        else -> "cloudy"
    }

    @Suppress("DEPRECATION")
    private fun placeName(ctx: Context, loc: Location): String = try {
        val list = Geocoder(ctx, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)
        val a = list?.firstOrNull()
        a?.locality ?: a?.subAdminArea ?: a?.adminArea ?: "your area"
    } catch (e: Exception) {
        "your area"
    }

    @SuppressLint("MissingPermission")
    private fun location(ctx: Context): Location? {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (granted) {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best.time) best = l
            }
            if (best == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val provider = lm.getProviders(true).firstOrNull()
                if (provider != null) {
                    val latch = CountDownLatch(1)
                    var got: Location? = null
                    lm.getCurrentLocation(provider, null, Executors.newSingleThreadExecutor()) {
                        got = it
                        latch.countDown()
                    }
                    latch.await(8, TimeUnit.SECONDS)
                    best = got
                }
            }
            if (best != null) {
                prefs.edit().putFloat("lat", best.latitude.toFloat()).putFloat("lon", best.longitude.toFloat()).apply()
                return best
            }
        }
        // Fall back to the last place we knew about, so the widget keeps working.
        if (prefs.contains("lat")) {
            return Location("saved").apply {
                latitude = prefs.getFloat("lat", 0f).toDouble()
                longitude = prefs.getFloat("lon", 0f).toDouble()
            }
        }
        return null
    }
}
