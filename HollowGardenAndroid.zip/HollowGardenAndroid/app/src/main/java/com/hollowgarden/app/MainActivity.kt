package com.hollowgarden.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var lastFetch = 0L

    private val askLocation =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshWeather() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // the game saves progress in localStorage
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
        }
        web.addJavascriptInterface(Bridge(), "Android")

        // Serves the bundled game from a real https origin so saving and audio behave.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(request.url.toString())))
                return true
            }

            override fun onPageFinished(view: WebView, url: String) = pushWeather()
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finish() }
        })

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        ) refreshWeather() else askLocation.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    override fun onResume() {
        super.onResume()
        if (System.currentTimeMillis() - lastFetch > 15 * 60_000) refreshWeather()
    }

    private fun refreshWeather() {
        lastFetch = System.currentTimeMillis()
        thread {
            WeatherFetcher.refresh(applicationContext)
            runOnUiThread {
                pushWeather()
                GardenWidget.updateAll(this)
            }
        }
    }

    /** Hands the latest weather to the game, which calls window.__setWeather. */
    private fun pushWeather() {
        val json = WeatherFetcher.cached(this) ?: return
        web.evaluateJavascript("window.__setWeather && window.__setWeather($json)", null)
    }

    inner class Bridge {
        /** The game calls this about once a minute so the widget can show garden status. */
        @JavascriptInterface
        fun saveSummary(json: String) {
            WeatherFetcher.saveSummary(applicationContext, json)
            GardenWidget.updateAll(applicationContext)
        }
    }
}
