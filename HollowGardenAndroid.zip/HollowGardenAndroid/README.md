# Hollow Garden for Android

A native Android app that wraps the Hollow Garden game and adds two things the web version cannot do:

- **Live weather where you are.** The app reads your approximate location, asks Open-Meteo (free, no API key) for the current weather, and the garden follows it: sunny, cloudy, rain, storm, snow, fog or windy.
- **A home-screen widget** showing the weather, your town, and how many plants are ready or thirsty.

I wrote this project but could not build or run it in my environment, so it has never been compiled. Expect to fix a small error or two the first time you open it in Android Studio.

## Get the APK without Android Studio

1. Make a free account at github.com and create a new empty repository.
2. Upload everything from this folder into it (use **Add file > Upload files** and drag the contents in, including the hidden `.github` folder).
3. Open the **Actions** tab, choose **Build APK** and press **Run workflow**.
4. When it finishes (about 5 minutes), open the run and download **HollowGarden-apk**. Unzip it to get `app-debug.apk`.
5. Send the APK to your phone, open it and allow "install unknown apps" when asked.

This is a debug build for your own phone. The Play Store needs the signed bundle described below.

## Build it with Android Studio

1. Install Android Studio (free).
2. Open this folder (`HollowGardenAndroid`) with **File > Open**.
3. Let it sync. It downloads Gradle and the Android SDK 35 on its own.
4. Plug in your phone with USB debugging on, or start an emulator, and press **Run**.
5. On the phone, press and hold the home screen, choose **Widgets**, find **Hollow Garden** and drag it out.

The game lives in `app/src/main/assets/index.html`. It uses Google Fonts when online and falls back to system fonts offline.

## Put it on the Play Store

1. Create a Google Play developer account (one-time fee, currently 25 USD) at play.google.com/console.
2. In Android Studio choose **Build > Generate Signed App Bundle / APK**, pick **Android App Bundle**, create a new keystore and keep it somewhere safe. Losing it means you cannot update the app.
3. Make a 512x512 app icon and a 1024x500 feature graphic, plus at least two phone screenshots. Android Studio's **Image Asset** tool can make the icon from `ic_launcher_foreground.xml`.
4. In Play Console create the app and upload the `.aab`.
5. Fill in the forms:
   - **Privacy policy URL.** Required because the app asks for location. Say that approximate location is used only to look up the weather, is sent to Open-Meteo, and is never stored on a server or shared. Host the page anywhere public.
   - **Data safety.** Declare approximate location, collected for app functionality, not shared for advertising.
   - **Content rating** questionnaire and **target audience**.
6. New personal developer accounts usually have to run a closed test with a group of testers for about two weeks before they can publish. Check Play Console for the current numbers.

Open-Meteo is free for non-commercial use. If you ever charge money or run ads, read their terms and use a commercial plan.

## Where things are

- `MainActivity.kt` shows the game in a WebView and asks for location permission.
- `WeatherFetcher.kt` finds your location and fetches the weather.
- `GardenWidget.kt` is the home-screen widget.
- `app/src/main/assets/index.html` is the game. The game calls `window.__setWeather` (set by the app) for weather and `Android.saveSummary` for widget data.
- `app/build.gradle.kts` holds the app id (`com.hollowgarden.app`), version code and name. Change the app id before publishing if you want your own.
